@echo off
node index.js
if errorlevel 1 (
  echo Backend exited with an error.
  pause
)
exit /b %errorlevel%
